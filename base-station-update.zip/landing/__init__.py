"""Diagnostic geometry only."""
