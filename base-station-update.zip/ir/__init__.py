"""Shared-array optical processing."""
